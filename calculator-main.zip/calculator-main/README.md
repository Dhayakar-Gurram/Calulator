# calculator
I created calculator which performs basic operations
